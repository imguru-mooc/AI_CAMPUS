#!/bin/bash
# run.sh — 프로그램을 N회 반복 실행해 실행 시간을 CSV로 저장
# 사용법: ./run.sh <실행파일> <반복횟수> [출력CSV]
# 예)     ./run.sh ./01_write_vs_printf 5 result.csv

if [ $# -lt 2 ]; then
    echo "사용법: $0 <실행파일> <반복횟수> [출력CSV]"
    exit 1
fi

PROG=$1
N=$2
OUT=${3:-result.csv}

echo "run,elapsed_ms" > "$OUT"
for i in $(seq 1 "$N"); do
    start=$(date +%s%N)
    "$PROG" > /dev/null
    end=$(date +%s%N)
    echo "$i,$(( (end - start) / 1000000 ))" >> "$OUT"
done
echo "저장 완료: $OUT"
cat "$OUT"
