/* 01_write_vs_printf.c — 라이브러리 함수(printf)와 시스템 콜(write) 비교
 * 빌드: make 01_write_vs_printf
 * 관찰: strace -e trace=write ./01_write_vs_printf
 *       strace -c ./01_write_vs_printf > /dev/null
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main(void)
{
    const char *msg = "hello from write()\n";

    /* 1) 시스템 콜 write(): fd 1(stdout)로 바로 커널에 요청 */
    write(1, msg, strlen(msg));

    /* 2) 라이브러리 함수 printf(): 먼저 stdio 버퍼에 쌓았다가 write()로 내보냄 */
    for (int i = 0; i < 5; i++)
        printf("printf line %d\n", i);

    /* 3) 버퍼를 비우지 않고 끝나도 exit 과정에서 fflush가 호출됨 */
    return 0;
}
