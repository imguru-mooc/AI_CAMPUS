/* 07_zombie.c — 좀비 프로세스 만들고 관찰하기
 * 빌드: make 07_zombie
 * 실행: ./07_zombie &
 *       ps -o pid,ppid,stat,cmd --ppid $!    (STAT 열의 Z 확인)
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void)
{
    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        return 1;
    }

    if (pid == 0) {
        printf("[자식 %d] 바로 종료합니다\n", getpid());
        exit(7);
    }

    printf("[부모 %d] 20초 동안 wait하지 않음 → 자식 %d는 좀비(Z)\n", getpid(), pid);
    fflush(stdout);
    sleep(20);

    int status;
    waitpid(pid, &status, 0);          /* 이제 수거 → 좀비 사라짐 */
    printf("[부모] 수거 완료, 종료 코드=%d\n", WEXITSTATUS(status));
    sleep(5);                          /* 수거 후 ps로 다시 확인할 시간 */
    return 0;
}
