/* 08_orphan.c — 부모가 먼저 끝나면 자식의 PPID가 바뀐다
 * 빌드: make 08_orphan
 * 실행: ./08_orphan   (3초 뒤 프롬프트가 돌아온 후 자식 출력이 이어짐)
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void)
{
    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        return 1;
    }

    if (pid == 0) {
        printf("[자식] 처음 PPID=%d\n", getppid());
        fflush(stdout);
        sleep(3);                       /* 그 사이 부모 종료 */
        printf("[자식] 고아가 된 후 PPID=%d (init 또는 subreaper)\n", getppid());
        exit(0);
    }

    printf("[부모 %d] 자식 %d를 기다리지 않고 1초 뒤 종료\n", getpid(), pid);
    sleep(1);
    return 0;
}
