/* 02_syscall_direct.c — glibc 래퍼 함수 vs syscall()로 직접 호출
 * 빌드: make 02_syscall_direct
 * 관찰: strace -e trace=getpid,write ./02_syscall_direct
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>

int main(void)
{
    pid_t a = getpid();                 /* glibc 래퍼 */
    long  b = syscall(SYS_getpid);      /* 시스템 콜 번호로 직접 호출 */

    printf("getpid()            = %d\n", a);
    printf("syscall(SYS_getpid) = %ld\n", b);
    printf("SYS_getpid 번호     = %d\n", SYS_getpid);
    printf("SYS_write  번호     = %d\n", SYS_write);

    syscall(SYS_write, 1, "직접 write 호출\n", sizeof("직접 write 호출\n") - 1);
    return 0;
}
