/* 04_proc_self.c — /proc/self/status에서 내 프로세스 정보 읽기
 * 빌드: make 04_proc_self
 * 실행: ./04_proc_self
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* key(예: "VmRSS")에 해당하는 줄의 값을 out에 복사. 성공 0, 실패 -1 */
static int read_status(const char *key, char *out, size_t size)
{
    FILE *fp = fopen("/proc/self/status", "r");
    if (fp == NULL) {
        perror("fopen");
        return -1;
    }

    char line[256];
    size_t klen = strlen(key);
    int found = -1;

    while (fgets(line, sizeof(line), fp) != NULL) {
        if (strncmp(line, key, klen) == 0 && line[klen] == ':') {
            char *v = line + klen + 1;
            while (*v == ' ' || *v == '\t')
                v++;
            v[strcspn(v, "\n")] = '\0';
            snprintf(out, size, "%s", v);
            found = 0;
            break;
        }
    }
    fclose(fp);
    return found;
}

int main(void)
{
    const char *keys[] = { "Name", "State", "Pid", "PPid", "Threads", "VmRSS" };
    char val[128];

    printf("--- malloc 전 ---\n");
    for (size_t i = 0; i < sizeof(keys) / sizeof(keys[0]); i++)
        if (read_status(keys[i], val, sizeof(val)) == 0)
            printf("%-8s %s\n", keys[i], val);

    /* 50MB를 할당하고 실제로 써야 RSS가 늘어난다 (Day 3 demand paging 예고) */
    size_t n = 50 * 1024 * 1024;
    char *buf = malloc(n);
    if (buf == NULL)
        return 1;
    memset(buf, 1, n);

    printf("--- 50MB 사용 후 ---\n");
    if (read_status("VmRSS", val, sizeof(val)) == 0)
        printf("%-8s %s\n", "VmRSS", val);

    free(buf);
    return 0;
}
