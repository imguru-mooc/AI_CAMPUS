/* 06_fork_exec_wait.c — fork → exec → wait, 종료 상태 확인
 * 빌드: make 06_fork_exec_wait
 * 실행: ./06_fork_exec_wait            (기본: ls -l /tmp)
 *       ./06_fork_exec_wait ls /nope   (실패하는 명령 → 종료 코드 2)
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
    char *def[] = { "ls", "-l", "/tmp", NULL };
    char **cmd = (argc > 1) ? &argv[1] : def;

    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        return 1;
    }

    if (pid == 0) {
        execvp(cmd[0], cmd);          /* 성공하면 이 아래는 실행되지 않음 */
        perror("execvp");
        _exit(127);                   /* exec 실패 관례: 127 */
    }

    int status;
    if (waitpid(pid, &status, 0) == -1) {
        perror("waitpid");
        return 1;
    }

    if (WIFEXITED(status))
        printf("[부모] 자식 %d 정상 종료, 종료 코드=%d\n", pid, WEXITSTATUS(status));
    else if (WIFSIGNALED(status))
        printf("[부모] 자식 %d 시그널로 종료, 시그널=%d\n", pid, WTERMSIG(status));
    return 0;
}
