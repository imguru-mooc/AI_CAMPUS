#!/bin/bash
# check_env.sh — Linux & Shell Day 1 실습 환경 점검
# 사용법: bash check_env.sh

ok()   { printf "  [ OK ] %s\n" "$*"; }
warn() { printf "  [WARN] %s\n" "$*"; }

echo "== 1. 운영체제와 커널 =="
. /etc/os-release
ok "배포판 : $PRETTY_NAME"
ok "커널   : $(uname -r) ($(uname -m))"

echo "== 2. CPU와 가상화 =="
CORES=$(nproc)
if [ "$CORES" -ge 2 ]; then ok "코어 수 : $CORES"; else warn "코어 수 : $CORES (2개 이상 권장 — VM이면 vCPU를 늘리세요)"; fi
VIRT=$(systemd-detect-virt 2>/dev/null || echo none)
ok "가상화 : $VIRT"
if grep -qi microsoft /proc/version; then warn "WSL 환경 — Day 4 커널 모듈 실습은 대체 과제로 진행"; fi

echo "== 3. Secure Boot =="
if command -v mokutil >/dev/null 2>&1; then
    ok "$(mokutil --sb-state 2>/dev/null || echo '확인 불가')"
else
    warn "mokutil 없음 (sudo apt install mokutil)"
fi

echo "== 4. sudo 권한 =="
if sudo -n true 2>/dev/null; then ok "sudo 사용 가능(비밀번호 캐시됨)"
elif id -nG | grep -qw sudo; then ok "sudo 그룹 소속"
else warn "sudo 권한 없음 — 강사에게 알려주세요"; fi

echo "== 5. 필수 도구 =="
for t in gcc make gdb strace valgrind perf stress-ng; do
    if command -v "$t" >/dev/null 2>&1; then ok "$t"; else warn "$t 없음"; fi
done
echo
echo "설치 명령: sudo apt install build-essential gdb strace valgrind stress-ng linux-tools-\$(uname -r) linux-headers-\$(uname -r)"
