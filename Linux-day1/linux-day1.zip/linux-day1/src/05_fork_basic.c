/* 05_fork_basic.c — fork() 반환값으로 부모/자식 구분
 * 빌드: make 05_fork_basic
 * 실행: ./05_fork_basic
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void)
{
    int x = 100;
    printf("[fork 전] PID=%d, x=%d\n", getpid(), x);
    fflush(stdout);   /* 버퍼를 비우지 않으면 자식에게 복사되어 두 번 출력될 수 있음 */

    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        exit(1);
    }

    if (pid == 0) {
        /* 자식: fork() 반환값 0 */
        x += 1;
        printf("[자식] PID=%d, PPID=%d, x=%d\n", getpid(), getppid(), x);
        exit(0);
    }

    /* 부모: fork() 반환값 = 자식 PID */
    x -= 1;
    wait(NULL);
    printf("[부모] PID=%d, 자식 PID=%d, x=%d\n", getpid(), pid, x);
    return 0;
}
