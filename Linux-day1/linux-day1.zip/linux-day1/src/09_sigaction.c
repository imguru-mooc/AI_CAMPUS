/* 09_sigaction.c — SIGINT(Ctrl+C) 처리와 SIGCHLD로 자식 자동 수거
 * 빌드: make 09_sigaction
 * 실행: ./09_sigaction   → Ctrl+C를 두 번 눌러 보기 (세 번째에 종료)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <sys/wait.h>

static volatile sig_atomic_t g_int_count = 0;

static void on_sigint(int sig)
{
    (void)sig;
    g_int_count++;
    /* 핸들러 안에서는 async-signal-safe 함수만: printf 대신 write */
    const char msg[] = "\n[핸들러] SIGINT 받음\n";
    write(1, msg, sizeof(msg) - 1);
}

static void on_sigchld(int sig)
{
    (void)sig;
    /* 끝난 자식을 모두 수거 → 좀비가 남지 않음 */
    while (waitpid(-1, NULL, WNOHANG) > 0)
        ;
}

int main(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sigemptyset(&sa.sa_mask);

    sa.sa_handler = on_sigint;
    sigaction(SIGINT, &sa, NULL);

    sa.sa_handler = on_sigchld;
    sa.sa_flags = SA_RESTART;          /* 시그널에 끊긴 sleep 외 시스템 콜 자동 재시작 */
    sigaction(SIGCHLD, &sa, NULL);

    /* 자식 하나를 만들어 2초 뒤 종료시킴 → SIGCHLD 핸들러가 수거 */
    if (fork() == 0) {
        sleep(2);
        _exit(0);
    }

    printf("PID=%d, Ctrl+C를 3번 누르면 종료합니다\n", getpid());
    while (g_int_count < 3)
        pause();                       /* 시그널이 올 때까지 잠듦 */

    printf("SIGINT 3회 → 종료\n");
    return 0;
}
