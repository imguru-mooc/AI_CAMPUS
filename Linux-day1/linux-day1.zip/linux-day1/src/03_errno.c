/* 03_errno.c — 시스템 콜 실패와 errno 확인
 * 빌드: make 03_errno
 * 실행: ./03_errno
 */
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>

static void try_open(const char *path, int flags)
{
    int fd = open(path, flags);
    if (fd == -1) {
        /* 실패 시 -1 반환 + errno에 원인 번호가 저장됨 */
        printf("%-22s → 실패: errno=%d (%s)\n", path, errno, strerror(errno));
        return;
    }
    printf("%-22s → 성공: fd=%d\n", path, fd);
    close(fd);
}

int main(void)
{
    try_open("/etc/hostname", O_RDONLY);   /* 성공 */
    try_open("/no/such/file", O_RDONLY);   /* ENOENT */
    try_open("/etc/shadow", O_RDONLY);     /* EACCES (일반 사용자) */
    try_open("/etc", O_WRONLY);            /* EISDIR */

    errno = 0;
    if (close(100) == -1)
        perror("close(100)");              /* EBADF, perror는 메시지 앞에 접두어를 붙임 */
    return 0;
}
