# Linux & Shell Day 1 — Shell 필수 · 시스템 콜 · 프로세스

> **오늘의 도착점:** `strace`로 시스템 콜을 관찰하고, fork → exec → wait를 반복하는 미니 셸 `myshell`을 C로 만든다.
>
> 실습 폴더: `~/linux-course/day1/` · 예제 소스: `src/` · 빈칸은 직접 입력 후 **채점** 버튼으로 확인

| 교시 | 주제 | 결과물 |
| --- | --- | --- |
| 1 | 오리엔테이션 · 환경 점검 | `check_env.sh` 실행 결과 |
| 2 | Shell 필수 | 명령 기록 `shell_notes.txt` |
| 3 | Makefile · 측정 스크립트 | `make`, `run.sh` |
| 4 | 시스템 콜과 커널 경계 | `01`, `02` 예제 |
| 5 | 에러 처리와 /proc | `03`, `04` 예제 |
| 6 | 프로세스 생성 | `05`, `06` 예제 |
| 7 | 좀비 · 고아 · 시그널 | `07`, `08`, `09` 예제 |
| 8 | 종합 실습 | `myshell.c` |

---

## 1교시 · 오리엔테이션과 환경 점검

### 1-1. 이 과목에서 하는 일

운영체제 활용 과목에서는 스케줄러·메모리·파일시스템이 **어떻게 동작하는지** 애니메이션으로 봤다. 이 과목에서는 같은 동작을 **C 프로그램으로 직접 일으키고 숫자로 측정**한다.

| Day | 주제 | 대표 결과물 |
| --- | --- | --- |
| 1 | 시스템 콜 · 프로세스 | `myshell.c` |
| 2 | 스케줄링 | `jitter.c` |
| 3 | 메모리 | `memlab.c` |
| 4 | 파일시스템 · sysfs | `sysmon.c`, `mysysfs.ko` |
| 5 | 쓰레드 · 동기화 | `edge_pipeline.c` |

### 1-2. 내 환경 확인하기

터미널을 열고(`Ctrl+Alt+T`) 아래를 따라 한다.

```bash
uname -r              # 커널 버전
lsb_release -a        # Ubuntu 버전
nproc                 # CPU 코어 수
```

**기대 출력 예시 (Ubuntu 24.04)**

```text
6.8.0-45-generic
Description:    Ubuntu 24.04.1 LTS
4
```

### 1-3. 개발 도구 설치

```bash
sudo apt update
sudo apt install -y build-essential gdb strace valgrind stress-ng \
     linux-tools-$(uname -r) linux-headers-$(uname -r) mokutil
```

### 1-4. 실습 폴더와 환경 점검 스크립트

```bash
mkdir -p ~/linux-course/day1
cd ~/linux-course/day1
# 강사가 안내한 주소에서 src 폴더를 내려받은 뒤
cd src
bash check_env.sh
```

`[WARN]`이 나온 항목은 손을 들어 보조강사에게 알린다. 특히 **코어 수 1개**(VM의 vCPU 부족)와 **sudo 권한 없음**은 Day 2 이전에 반드시 해결해야 한다.

**`src/check_env.sh`**

```bash
#!/bin/bash
# check_env.sh — Linux & Shell Day 1 실습 환경 점검
# 사용법: bash check_env.sh

ok()   { printf "  [ OK ] %s\n" "$*"; }
warn() { printf "  [WARN] %s\n" "$*"; }

echo "== 1. 운영체제와 커널 =="
. /etc/os-release
ok "배포판 : $PRETTY_NAME"
ok "커널   : $(uname -r) ($(uname -m))"

echo "== 2. CPU와 가상화 =="
CORES=$(nproc)
if [ "$CORES" -ge 2 ]; then ok "코어 수 : $CORES"; else warn "코어 수 : $CORES (2개 이상 권장 — VM이면 vCPU를 늘리세요)"; fi
VIRT=$(systemd-detect-virt 2>/dev/null || echo none)
ok "가상화 : $VIRT"
if grep -qi microsoft /proc/version; then warn "WSL 환경 — Day 4 커널 모듈 실습은 대체 과제로 진행"; fi

echo "== 3. Secure Boot =="
if command -v mokutil >/dev/null 2>&1; then
    ok "$(mokutil --sb-state 2>/dev/null || echo '확인 불가')"
else
    warn "mokutil 없음 (sudo apt install mokutil)"
fi

echo "== 4. sudo 권한 =="
if sudo -n true 2>/dev/null; then ok "sudo 사용 가능(비밀번호 캐시됨)"
elif id -nG | grep -qw sudo; then ok "sudo 그룹 소속"
else warn "sudo 권한 없음 — 강사에게 알려주세요"; fi

echo "== 5. 필수 도구 =="
for t in gcc make gdb strace valgrind perf stress-ng; do
    if command -v "$t" >/dev/null 2>&1; then ok "$t"; else warn "$t 없음"; fi
done
echo
echo "설치 명령: sudo apt install build-essential gdb strace valgrind stress-ng linux-tools-\$(uname -r) linux-headers-\$(uname -r)"
```

### ✅ 1교시 확인

1. 현재 실행 중인 커널 버전을 출력하는 명령은 `uname ( 1 )________` 이다.
2. CPU 코어 수를 숫자 하나로 출력하는 명령은 ( 2 )________ 이다.
3. Ubuntu 패키지를 설치하는 명령은 `sudo ( 3 )________ install 패키지명` 이다.

---

## 2교시 · Shell 필수 (압축)

이 과목에서 Shell은 **C 프로그램을 빌드·실행·측정하는 도구**로만 쓴다. 아래 명령만 손에 익히면 충분하다.

### 2-1. 이동과 확인

| 명령 | 의미 | 예 |
| --- | --- | --- |
| `pwd` | 현재 위치 출력 | `pwd` |
| `cd` | 디렉터리 이동 | `cd ~/linux-course`, `cd ..`, `cd -` |
| `ls -l` | 자세히 목록 보기 | `ls -la /proc/self` |
| `cat` / `less` | 파일 내용 보기 | `cat /proc/cpuinfo`, `less /var/log/syslog` |

- 절대 경로는 `/`로 시작한다: `/home/user/linux-course`
- 상대 경로는 현재 위치 기준이다: `../day2`
- `~` 는 내 홈 디렉터리, `.` 은 현재, `..` 은 상위 디렉터리

### 2-2. 파일 조작

```bash
mkdir -p test/a/b        # 중간 디렉터리까지 한 번에
touch test/hello.c       # 빈 파일 생성
cp test/hello.c test/a/  # 복사
mv test/hello.c test/main.c   # 이름 변경(이동)
rm -r test               # 디렉터리째 삭제 — 되돌릴 수 없음!
```

### 2-3. 권한

```bash
ls -l run.sh
# -rw-r--r-- 1 user user 512 Oct  2 09:10 run.sh
chmod +x run.sh
ls -l run.sh
# -rwxr-xr-x 1 user user 512 Oct  2 09:10 run.sh
./run.sh                 # 이제 실행 가능
```

`rwx` 세 묶음은 차례대로 **소유자 · 그룹 · 그 외**의 권한이다. 실행 권한이 없으면 `./run.sh`는 `Permission denied`가 난다.

### 2-4. 리다이렉션과 파이프

| 기호 | 의미 | 예 |
| --- | --- | --- |
| `>` | 출력을 파일로(덮어쓰기) | `./a.out > out.txt` |
| `>>` | 출력을 파일 끝에 추가 | `date >> log.txt` |
| `2>` | 에러 출력만 파일로 | `./a.out 2> err.txt` |
| `2>&1` | 에러를 표준 출력과 같은 곳으로 | `make > build.log 2>&1` |
| `\|` | 앞 명령의 출력을 뒤 명령의 입력으로 | `ps aux \| grep bash` |

```bash
grep processor /proc/cpuinfo | wc -l    # 코어 수 세기
ps aux | grep -v grep | grep bash       # bash 프로세스 찾기
```

### 2-5. 백그라운드 실행

```bash
sleep 30 &      # 끝에 & → 백그라운드에서 실행, 프롬프트 즉시 복귀
jobs            # 내 백그라운드 작업 목록
echo $!         # 방금 백그라운드로 띄운 프로세스의 PID
kill %1         # 1번 작업 종료
```

### ✅ 2교시 확인

1. 실행 권한을 추가하는 명령은 `chmod ( 4 )________ run.sh` 이다.
2. 표준 출력과 에러 출력을 모두 `log.txt`로 보내려면 `make > log.txt ( 5 )________` 라고 쓴다.
3. 앞 명령의 출력을 뒤 명령의 입력으로 연결하는 기호는 ( 6 )________ 이다.
4. 방금 백그라운드로 실행한 프로세스의 PID가 저장된 변수는 ( 7 )________ 이다.

---

## 3교시 · Makefile과 측정 스크립트

### 3-1. 왜 Makefile인가

예제가 10개라면 `gcc -Wall -Wextra -g -o 01 01.c`를 10번 쳐야 한다. Makefile은 **"무엇을 무엇으로 어떻게 만드는가"** 를 적어 두면, 바뀐 파일만 다시 빌드한다.

**`src/Makefile`**

```make
# Linux & Shell Day 1 — 공통 Makefile
# make        : 모든 예제 빌드
# make clean  : 실행 파일 삭제
CC      = gcc
CFLAGS  = -Wall -Wextra -g
SRCS    = $(wildcard *.c)
TARGETS = $(SRCS:.c=)

all: $(TARGETS)

%: %.c
	$(CC) $(CFLAGS) -o $@ $<

clean:
	rm -f $(TARGETS)

.PHONY: all clean
```

| 요소 | 의미 |
| --- | --- |
| `CC`, `CFLAGS` | 변수. `$(CFLAGS)` 처럼 꺼내 쓴다 |
| `$(wildcard *.c)` | 현재 폴더의 모든 `.c` 파일 목록 |
| `$(SRCS:.c=)` | 목록에서 `.c` 를 지운 것 → 실행 파일 이름 |
| `%: %.c` | 패턴 규칙. `foo`는 `foo.c`로 만든다 |
| `$@` / `$<` | 만들 대상 / 첫 번째 재료 |
| 탭 | 명령 줄은 반드시 **탭**으로 시작 (스페이스면 `missing separator` 에러) |

```bash
make                     # 전부 빌드
make 03_errno            # 하나만 빌드
touch 03_errno.c && make # 03만 다시 빌드되는 것 확인
make clean
```

### 3-2. 반복 측정 스크립트 run.sh

측정은 한 번으로 믿지 않는다. 같은 프로그램을 N번 실행해 시간을 CSV로 남긴다.

**`src/run.sh`**

```bash
#!/bin/bash
# run.sh — 프로그램을 N회 반복 실행해 실행 시간을 CSV로 저장
# 사용법: ./run.sh <실행파일> <반복횟수> [출력CSV]
# 예)     ./run.sh ./01_write_vs_printf 5 result.csv

if [ $# -lt 2 ]; then
    echo "사용법: $0 <실행파일> <반복횟수> [출력CSV]"
    exit 1
fi

PROG=$1
N=$2
OUT=${3:-result.csv}

echo "run,elapsed_ms" > "$OUT"
for i in $(seq 1 "$N"); do
    start=$(date +%s%N)
    "$PROG" > /dev/null
    end=$(date +%s%N)
    echo "$i,$(( (end - start) / 1000000 ))" >> "$OUT"
done
echo "저장 완료: $OUT"
cat "$OUT"
```

| 문법 | 의미 |
| --- | --- |
| `#!/bin/bash` | shebang. 이 파일을 bash로 실행하라는 표시 |
| `$1`, `$2`, `$#` | 첫째·둘째 인자, 인자 개수 |
| `${3:-result.csv}` | 셋째 인자가 없으면 기본값 사용 |
| `$(seq 1 "$N")` | 명령의 출력을 그 자리에 대입 (명령 치환) |
| `$(( ... ))` | 정수 산술 |

```bash
chmod +x run.sh
./run.sh ./02_syscall_direct 5 r.csv
```

### ✅ 3교시 확인

1. Makefile에서 명령 줄은 반드시 ( 8 )________ 문자로 시작해야 한다.
2. 패턴 규칙에서 "만들 대상"을 뜻하는 자동 변수는 ( 9 )________ 이다.
3. 셸 스크립트에서 인자 개수를 담은 변수는 ( 10 )________ 이다.
4. 셸에서 명령의 출력 결과를 그 자리에 넣는 문법은 ( 11 )________ 이다.

---

## 4교시 · 시스템 콜과 커널 경계

### 4-1. 사용자 모드와 커널 모드

프로그램은 평소 **사용자 모드**에서 돈다. 파일·화면·네트워크·프로세스 생성처럼 하드웨어나 다른 프로세스에 영향을 주는 일은 직접 못 하고, **시스템 콜**로 커널에 부탁해야 한다. 시스템 콜이 호출되면 CPU는 **커널 모드**로 전환되어 커널 코드를 실행한 뒤 결과를 들고 돌아온다.

```text
[사용자 모드]  printf() ─▶ (glibc 버퍼) ─▶ write() 래퍼
                                              │ syscall 명령, 번호=1
───────────────────────────────────────────── ▼ ───────────
[커널 모드]                              sys_write() ─▶ 터미널 드라이버
```

- `man 2 write` → 섹션 2: **시스템 콜**
- `man 3 printf` → 섹션 3: **C 라이브러리 함수**

### 4-2. 예제 01 — printf와 write

**`src/01_write_vs_printf.c`**

```c
/* 01_write_vs_printf.c — 라이브러리 함수(printf)와 시스템 콜(write) 비교
 * 빌드: make 01_write_vs_printf
 * 관찰: strace -e trace=write ./01_write_vs_printf
 *       strace -c ./01_write_vs_printf > /dev/null
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main(void)
{
    const char *msg = "hello from write()\n";

    /* 1) 시스템 콜 write(): fd 1(stdout)로 바로 커널에 요청 */
    write(1, msg, strlen(msg));

    /* 2) 라이브러리 함수 printf(): 먼저 stdio 버퍼에 쌓았다가 write()로 내보냄 */
    for (int i = 0; i < 5; i++)
        printf("printf line %d\n", i);

    /* 3) 버퍼를 비우지 않고 끝나도 exit 과정에서 fflush가 호출됨 */
    return 0;
}
```

```bash
make 01_write_vs_printf
./01_write_vs_printf
./01_write_vs_printf | cat            # 출력 순서가 바뀌는가?
strace -e trace=write ./01_write_vs_printf
```

**관찰 포인트**

- 터미널에 출력할 때 printf는 **줄 단위 버퍼링** → 줄마다 write가 호출된다.
- 파이프(`| cat`)나 파일로 보낼 때는 **블록 단위 버퍼링** → printf 5줄이 write **한 번**으로 합쳐지고, 먼저 호출한 write 문장보다 늦게 나온다.

```text
write(1, "hello from write()\n", 19)    = 19
write(1, "printf line 0\nprintf line 1\n"..., 70) = 70   ← 파이프일 때
```

### 4-3. 예제 02 — 래퍼 없이 직접 호출

**`src/02_syscall_direct.c`**

```c
/* 02_syscall_direct.c — glibc 래퍼 함수 vs syscall()로 직접 호출
 * 빌드: make 02_syscall_direct
 * 관찰: strace -e trace=getpid,write ./02_syscall_direct
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>

int main(void)
{
    pid_t a = getpid();                 /* glibc 래퍼 */
    long  b = syscall(SYS_getpid);      /* 시스템 콜 번호로 직접 호출 */

    printf("getpid()            = %d\n", a);
    printf("syscall(SYS_getpid) = %ld\n", b);
    printf("SYS_getpid 번호     = %d\n", SYS_getpid);
    printf("SYS_write  번호     = %d\n", SYS_write);

    syscall(SYS_write, 1, "직접 write 호출\n", sizeof("직접 write 호출\n") - 1);
    return 0;
}
```

```bash
make 02_syscall_direct && ./02_syscall_direct
strace -c ./02_syscall_direct > /dev/null    # 호출된 시스템 콜 통계
```

`getpid()`와 `syscall(SYS_getpid)`는 같은 값을 돌려준다. glibc 함수는 시스템 콜 번호를 레지스터에 넣고 `syscall` 명령을 실행하는 **얇은 포장(래퍼)** 이다. x86_64에서 `write`는 1번, `getpid`는 39번이다.

### ✅ 4교시 확인

1. 시스템 콜이 호출되면 CPU는 사용자 모드에서 ( 12 )________ 모드로 전환된다.
2. 시스템 콜 설명서를 보려면 `man ( 13 )________ write` 처럼 섹션 번호를 붙인다.
3. 프로그램이 호출한 시스템 콜을 추적하는 도구는 ( 14 )________ 이다.
4. 출력이 파이프로 갈 때 printf는 ( 15 )________ 단위로 버퍼링한다.

---

## 5교시 · 에러 처리와 /proc

### 5-1. 시스템 콜은 실패한다

대부분의 시스템 콜은 실패하면 **-1을 반환**하고, 원인 번호를 전역 변수 **`errno`** 에 남긴다. 반환값을 검사하지 않는 코드는 실패해도 모른 채 다음 줄로 간다.

| errno | 이름 | 흔한 원인 |
| --- | --- | --- |
| 2 | `ENOENT` | 파일·경로가 없음 |
| 13 | `EACCES` | 권한 없음 |
| 9 | `EBADF` | 열려 있지 않은 fd |
| 21 | `EISDIR` | 디렉터리를 쓰기로 열려 함 |

**`src/03_errno.c`**

```c
/* 03_errno.c — 시스템 콜 실패와 errno 확인
 * 빌드: make 03_errno
 * 실행: ./03_errno
 */
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>

static void try_open(const char *path, int flags)
{
    int fd = open(path, flags);
    if (fd == -1) {
        /* 실패 시 -1 반환 + errno에 원인 번호가 저장됨 */
        printf("%-22s → 실패: errno=%d (%s)\n", path, errno, strerror(errno));
        return;
    }
    printf("%-22s → 성공: fd=%d\n", path, fd);
    close(fd);
}

int main(void)
{
    try_open("/etc/hostname", O_RDONLY);   /* 성공 */
    try_open("/no/such/file", O_RDONLY);   /* ENOENT */
    try_open("/etc/shadow", O_RDONLY);     /* EACCES (일반 사용자) */
    try_open("/etc", O_WRONLY);            /* EISDIR */

    errno = 0;
    if (close(100) == -1)
        perror("close(100)");              /* EBADF, perror는 메시지 앞에 접두어를 붙임 */
    return 0;
}
```

```text
/etc/hostname          → 성공: fd=3
/no/such/file          → 실패: errno=2 (No such file or directory)
/etc/shadow            → 실패: errno=13 (Permission denied)
/etc                   → 실패: errno=21 (Is a directory)
close(100): Bad file descriptor
```

> `sudo ./03_errno`로 실행하면 `/etc/shadow`는 성공한다. root는 권한 검사를 통과하기 때문이다.

**규칙:** errno는 **실패했을 때만** 의미가 있다. 성공한 호출 뒤의 errno 값은 믿지 않는다.

### 5-2. /proc — 커널이 보여 주는 가상 파일

`/proc`은 디스크에 없는 **가상 파일시스템**이다. 파일을 읽는 순간 커널이 그때의 값을 만들어 준다. `/proc/self`는 "지금 이 파일을 읽는 프로세스 자신"을 가리킨다.

```bash
cat /proc/self/status | head -10
ls -l /proc/self/fd
cat /proc/loadavg
```

### 5-3. 예제 04 — C에서 /proc 읽기

**`src/04_proc_self.c`**

```c
/* 04_proc_self.c — /proc/self/status에서 내 프로세스 정보 읽기
 * 빌드: make 04_proc_self
 * 실행: ./04_proc_self
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* key(예: "VmRSS")에 해당하는 줄의 값을 out에 복사. 성공 0, 실패 -1 */
static int read_status(const char *key, char *out, size_t size)
{
    FILE *fp = fopen("/proc/self/status", "r");
    if (fp == NULL) {
        perror("fopen");
        return -1;
    }

    char line[256];
    size_t klen = strlen(key);
    int found = -1;

    while (fgets(line, sizeof(line), fp) != NULL) {
        if (strncmp(line, key, klen) == 0 && line[klen] == ':') {
            char *v = line + klen + 1;
            while (*v == ' ' || *v == '\t')
                v++;
            v[strcspn(v, "\n")] = '\0';
            snprintf(out, size, "%s", v);
            found = 0;
            break;
        }
    }
    fclose(fp);
    return found;
}

int main(void)
{
    const char *keys[] = { "Name", "State", "Pid", "PPid", "Threads", "VmRSS" };
    char val[128];

    printf("--- malloc 전 ---\n");
    for (size_t i = 0; i < sizeof(keys) / sizeof(keys[0]); i++)
        if (read_status(keys[i], val, sizeof(val)) == 0)
            printf("%-8s %s\n", keys[i], val);

    /* 50MB를 할당하고 실제로 써야 RSS가 늘어난다 (Day 3 demand paging 예고) */
    size_t n = 50 * 1024 * 1024;
    char *buf = malloc(n);
    if (buf == NULL)
        return 1;
    memset(buf, 1, n);

    printf("--- 50MB 사용 후 ---\n");
    if (read_status("VmRSS", val, sizeof(val)) == 0)
        printf("%-8s %s\n", "VmRSS", val);

    free(buf);
    return 0;
}
```

```text
--- malloc 전 ---
Name     04_proc_self
State    R (running)
Pid      5120
PPid     4890
Threads  1
VmRSS    1508 kB
--- 50MB 사용 후 ---
VmRSS    52712 kB
```

`VmRSS`는 실제로 물리 메모리를 차지하는 크기다. `malloc`만 하고 `memset`을 지우면 RSS가 거의 늘지 않는다 — Day 3에서 그 이유(demand paging)를 측정한다.

### ✅ 5교시 확인

1. 시스템 콜이 실패하면 대부분 ( 16 )________ 을 반환한다.
2. 실패 원인 번호가 저장되는 전역 변수는 ( 17 )________ 이다.
3. 없는 파일을 열려고 할 때 errno 이름은 ( 18 )________ 이다.
4. 현재 프로세스 자신의 정보를 가리키는 /proc 경로는 `/proc/( 19 )________` 이다.

---

## 6교시 · 프로세스 생성

### 6-1. fork — 하나가 둘이 된다

`fork()`는 호출한 프로세스를 복제한다. **한 번 호출해 두 번 반환**한다.

| 반환값 | 누가 받나 | 의미 |
| --- | --- | --- |
| `-1` | 부모 | 실패 (프로세스 생성 불가) |
| `0` | 자식 | "나는 자식이다" |
| `> 0` | 부모 | 새로 태어난 자식의 PID |

**`src/05_fork_basic.c`**

```c
/* 05_fork_basic.c — fork() 반환값으로 부모/자식 구분
 * 빌드: make 05_fork_basic
 * 실행: ./05_fork_basic
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void)
{
    int x = 100;
    printf("[fork 전] PID=%d, x=%d\n", getpid(), x);
    fflush(stdout);   /* 버퍼를 비우지 않으면 자식에게 복사되어 두 번 출력될 수 있음 */

    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        exit(1);
    }

    if (pid == 0) {
        /* 자식: fork() 반환값 0 */
        x += 1;
        printf("[자식] PID=%d, PPID=%d, x=%d\n", getpid(), getppid(), x);
        exit(0);
    }

    /* 부모: fork() 반환값 = 자식 PID */
    x -= 1;
    wait(NULL);
    printf("[부모] PID=%d, 자식 PID=%d, x=%d\n", getpid(), pid, x);
    return 0;
}
```

```text
[fork 전] PID=177, x=100
[자식] PID=178, PPID=177, x=101
[부모] PID=177, 자식 PID=178, x=99
```

자식의 `x`가 101, 부모의 `x`가 99인 이유: fork 후 두 프로세스는 **메모리를 따로** 가진다. (실제로는 Copy-on-Write로 쓰는 순간에 복사된다 — Day 3에서 측정)

> `fflush(stdout)`를 지우고 `./05_fork_basic | cat`으로 실행해 보라. "fork 전" 줄이 두 번 나온다. 버퍼에 남은 내용까지 자식에게 복제되기 때문이다.

### 6-2. exec와 wait

- **exec**: 현재 프로세스의 코드·데이터를 새 프로그램으로 **통째로 교체**한다. PID는 그대로다. 성공하면 돌아오지 않는다.
- **wait / waitpid**: 부모가 자식의 종료를 기다리고 **종료 상태**를 받는다.

| 매크로 | 의미 |
| --- | --- |
| `WIFEXITED(s)` | `exit()`로 정상 종료했는가 |
| `WEXITSTATUS(s)` | 그때의 종료 코드(0~255) |
| `WIFSIGNALED(s)` | 시그널로 죽었는가 |
| `WTERMSIG(s)` | 어떤 시그널이었나 |

**`src/06_fork_exec_wait.c`**

```c
/* 06_fork_exec_wait.c — fork → exec → wait, 종료 상태 확인
 * 빌드: make 06_fork_exec_wait
 * 실행: ./06_fork_exec_wait            (기본: ls -l /tmp)
 *       ./06_fork_exec_wait ls /nope   (실패하는 명령 → 종료 코드 2)
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
    char *def[] = { "ls", "-l", "/tmp", NULL };
    char **cmd = (argc > 1) ? &argv[1] : def;

    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        return 1;
    }

    if (pid == 0) {
        execvp(cmd[0], cmd);          /* 성공하면 이 아래는 실행되지 않음 */
        perror("execvp");
        _exit(127);                   /* exec 실패 관례: 127 */
    }

    int status;
    if (waitpid(pid, &status, 0) == -1) {
        perror("waitpid");
        return 1;
    }

    if (WIFEXITED(status))
        printf("[부모] 자식 %d 정상 종료, 종료 코드=%d\n", pid, WEXITSTATUS(status));
    else if (WIFSIGNALED(status))
        printf("[부모] 자식 %d 시그널로 종료, 시그널=%d\n", pid, WTERMSIG(status));
    return 0;
}
```

```bash
./06_fork_exec_wait                 # 종료 코드=0
./06_fork_exec_wait ls /nope        # 종료 코드=2
./06_fork_exec_wait nosuchcmd       # execvp 실패 → 종료 코드=127
./06_fork_exec_wait sleep 30        # 다른 터미널에서 kill → 시그널=15
```

### ✅ 6교시 확인

1. fork()가 자식 프로세스에게 돌려주는 값은 ( 20 )________ 이다.
2. exec 계열 함수가 성공하면 호출한 다음 줄은 ( 21 )________.
3. 자식이 exit()로 끝났는지 검사하는 매크로는 ( 22 )________ 이다.
4. exec 실패 시 관례적으로 쓰는 종료 코드는 ( 23 )________ 이다.

---

## 7교시 · 좀비 · 고아 · 시그널

### 7-1. 좀비 — 끝났지만 수거되지 않은 자식

자식이 끝나도 커널은 **종료 상태를 부모가 가져갈 때까지** 프로세스 테이블 한 칸을 남겨 둔다. 이 상태가 좀비(`Z`, `<defunct>`)다. 부모가 `wait`하면 사라진다.

**`src/07_zombie.c`**

```c
/* 07_zombie.c — 좀비 프로세스 만들고 관찰하기
 * 빌드: make 07_zombie
 * 실행: ./07_zombie &
 *       ps -o pid,ppid,stat,cmd --ppid $!    (STAT 열의 Z 확인)
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void)
{
    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        return 1;
    }

    if (pid == 0) {
        printf("[자식 %d] 바로 종료합니다\n", getpid());
        exit(7);
    }

    printf("[부모 %d] 20초 동안 wait하지 않음 → 자식 %d는 좀비(Z)\n", getpid(), pid);
    fflush(stdout);
    sleep(20);

    int status;
    waitpid(pid, &status, 0);          /* 이제 수거 → 좀비 사라짐 */
    printf("[부모] 수거 완료, 종료 코드=%d\n", WEXITSTATUS(status));
    sleep(5);                          /* 수거 후 ps로 다시 확인할 시간 */
    return 0;
}
```

```bash
./07_zombie &
ps -o pid,ppid,stat,cmd --ppid $!
```

```text
  PID  PPID STAT CMD
 6021  6020 Z    [07_zombie] <defunct>
```

20초 뒤 부모가 `waitpid`를 호출하면 다시 `ps`를 쳐 봐도 좀비가 없다.

### 7-2. 고아 — 부모가 먼저 끝난 자식

**`src/08_orphan.c`**

```c
/* 08_orphan.c — 부모가 먼저 끝나면 자식의 PPID가 바뀐다
 * 빌드: make 08_orphan
 * 실행: ./08_orphan   (3초 뒤 프롬프트가 돌아온 후 자식 출력이 이어짐)
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void)
{
    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        return 1;
    }

    if (pid == 0) {
        printf("[자식] 처음 PPID=%d\n", getppid());
        fflush(stdout);
        sleep(3);                       /* 그 사이 부모 종료 */
        printf("[자식] 고아가 된 후 PPID=%d (init 또는 subreaper)\n", getppid());
        exit(0);
    }

    printf("[부모 %d] 자식 %d를 기다리지 않고 1초 뒤 종료\n", getpid(), pid);
    sleep(1);
    return 0;
}
```

부모가 먼저 끝나면 자식은 **init(PID 1) 또는 subreaper**가 입양한다. Ubuntu 데스크톱에서는 로그인 세션의 `systemd --user`가 subreaper라서 PPID가 1이 아닌 다른 숫자로 바뀔 수 있다. `ps -p <PPID> -o cmd`로 누구인지 확인해 보라.

### 7-3. 시그널과 sigaction

시그널은 커널이 프로세스에 보내는 **비동기 알림**이다.

| 시그널 | 번호 | 언제 | 기본 동작 |
| --- | --- | --- | --- |
| `SIGINT` | 2 | Ctrl+C | 종료 |
| `SIGKILL` | 9 | `kill -9` | 종료 (잡을 수 없음) |
| `SIGTERM` | 15 | `kill` 기본값 | 종료 |
| `SIGCHLD` | 17 | 자식이 끝났을 때 | 무시 |

**`src/09_sigaction.c`**

```c
/* 09_sigaction.c — SIGINT(Ctrl+C) 처리와 SIGCHLD로 자식 자동 수거
 * 빌드: make 09_sigaction
 * 실행: ./09_sigaction   → Ctrl+C를 두 번 눌러 보기 (세 번째에 종료)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <sys/wait.h>

static volatile sig_atomic_t g_int_count = 0;

static void on_sigint(int sig)
{
    (void)sig;
    g_int_count++;
    /* 핸들러 안에서는 async-signal-safe 함수만: printf 대신 write */
    const char msg[] = "\n[핸들러] SIGINT 받음\n";
    write(1, msg, sizeof(msg) - 1);
}

static void on_sigchld(int sig)
{
    (void)sig;
    /* 끝난 자식을 모두 수거 → 좀비가 남지 않음 */
    while (waitpid(-1, NULL, WNOHANG) > 0)
        ;
}

int main(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sigemptyset(&sa.sa_mask);

    sa.sa_handler = on_sigint;
    sigaction(SIGINT, &sa, NULL);

    sa.sa_handler = on_sigchld;
    sa.sa_flags = SA_RESTART;          /* 시그널에 끊긴 sleep 외 시스템 콜 자동 재시작 */
    sigaction(SIGCHLD, &sa, NULL);

    /* 자식 하나를 만들어 2초 뒤 종료시킴 → SIGCHLD 핸들러가 수거 */
    if (fork() == 0) {
        sleep(2);
        _exit(0);
    }

    printf("PID=%d, Ctrl+C를 3번 누르면 종료합니다\n", getpid());
    while (g_int_count < 3)
        pause();                       /* 시그널이 올 때까지 잠듦 */

    printf("SIGINT 3회 → 종료\n");
    return 0;
}
```

**핸들러 작성 규칙**

- 핸들러에서는 `printf` 대신 `write` 같은 **async-signal-safe** 함수만 쓴다.
- 핸들러와 main이 함께 쓰는 변수는 `volatile sig_atomic_t`로 선언한다.
- `SIGCHLD` 핸들러에서 `waitpid(-1, NULL, WNOHANG)`을 **반복**해야 동시에 끝난 자식까지 모두 수거한다.

### ✅ 7교시 확인

1. ps의 STAT 열에서 좀비 프로세스는 ( 24 )________ 로 표시된다.
2. 좀비를 없애려면 부모가 ( 25 )________ 를 호출해야 한다.
3. 핸들러로 잡을 수 없는 종료 시그널은 ( 26 )________ 이다.
4. 자식이 종료되면 부모에게 전달되는 시그널은 ( 27 )________ 이다.

---

## 8교시 · 종합 실습 — myshell 만들기

### 8-1. 셸의 정체

우리가 매일 쓰는 bash도 결국 아래 루프다.

```text
for (;;) {
    프롬프트 출력 → 한 줄 읽기 → 단어로 자르기
    내장 명령(cd, exit)이면 셸이 직접 처리
    아니면 fork → 자식은 execvp → 부모는 waitpid
    종료 코드 저장
}
```

**왜 `cd`는 내장 명령이어야 하나?** `cd`를 자식 프로세스에서 실행하면 **자식의** 현재 디렉터리만 바뀌고, 자식이 끝나면 사라진다. 셸 자신의 위치를 바꾸려면 셸 프로세스가 직접 `chdir()`을 호출해야 한다.

### 8-2. 전체 코드

**`src/myshell.c`**

```c
/* myshell.c — Day 1 종합 실습: fork-exec-wait 루프로 만드는 미니 셸
 * 빌드: make myshell
 * 실행: ./myshell
 * 관찰: strace -f -e trace=clone,execve,wait4 ./myshell
 *
 * 지원: 일반 명령 실행, 내장 명령 exit / cd, 직전 종료 코드 표시
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

#define MAX_LINE 1024
#define MAX_ARGS 64

/* line을 공백 기준으로 잘라 argv에 담고 인자 개수를 반환 */
static int parse(char *line, char *argv[])
{
    int argc = 0;
    char *tok = strtok(line, " \t\n");
    while (tok != NULL && argc < MAX_ARGS - 1) {
        argv[argc++] = tok;
        tok = strtok(NULL, " \t\n");
    }
    argv[argc] = NULL;                 /* execvp는 NULL로 끝나는 배열을 요구 */
    return argc;
}

int main(void)
{
    char line[MAX_LINE];
    char *argv[MAX_ARGS];
    int last = 0;                      /* 직전 명령의 종료 코드 */

    signal(SIGINT, SIG_IGN);           /* 셸 자신은 Ctrl+C로 죽지 않음 */

    for (;;) {
        printf("myshell[%d]$ ", last);
        fflush(stdout);

        if (fgets(line, sizeof(line), stdin) == NULL) {   /* Ctrl+D */
            printf("\n");
            break;
        }

        int argc = parse(line, argv);
        if (argc == 0)
            continue;

        /* 내장 명령: 자식이 아니라 셸 자신이 처리해야 하는 것 */
        if (strcmp(argv[0], "exit") == 0)
            break;
        if (strcmp(argv[0], "cd") == 0) {
            const char *dir = (argc > 1) ? argv[1] : getenv("HOME");
            if (chdir(dir) == -1) {
                perror("cd");
                last = 1;
            } else {
                last = 0;
            }
            continue;
        }

        pid_t pid = fork();
        if (pid == -1) {
            perror("fork");
            continue;
        }
        if (pid == 0) {
            signal(SIGINT, SIG_DFL);   /* 자식은 Ctrl+C에 정상 반응 */
            execvp(argv[0], argv);
            perror(argv[0]);
            _exit(127);
        }

        int status;
        waitpid(pid, &status, 0);
        if (WIFEXITED(status))
            last = WEXITSTATUS(status);
        else if (WIFSIGNALED(status))
            last = 128 + WTERMSIG(status);   /* bash와 같은 관례 */
    }
    return 0;
}
```

### 8-3. 실행과 관찰

```bash
make myshell
./myshell
```

```text
myshell[0]$ echo hi
hi
myshell[0]$ ls /nope
ls: cannot access '/nope': No such file or directory
myshell[2]$ cd /tmp
myshell[0]$ pwd
/tmp
myshell[0]$ sleep 100        ← Ctrl+C
myshell[130]$ exit
```

다른 터미널에서 시스템 콜 흐름을 본다.

```bash
strace -f -e trace=clone,execve,wait4 ./myshell
```

### 8-4. 도전 과제 (선택)

1. `myshell[0]` 대신 현재 디렉터리를 프롬프트에 표시하기 (`getcwd`)
2. 명령 끝에 `&`가 있으면 기다리지 않고 백그라운드로 실행하기 (좀비가 남지 않게 `SIGCHLD` 처리)
3. `>` 리다이렉션 지원하기 (자식에서 `open` + `dup2(fd, 1)` 후 exec — Day 4 예고)

### ✅ 8교시 확인

1. `cd`는 셸 프로세스 자신이 ( 28 )________ 을 호출해야 하므로 내장 명령으로 처리한다.
2. execvp에 넘기는 인자 배열의 마지막 원소는 ( 29 )________ 이어야 한다.
3. bash 관례상 SIGINT(2번)로 죽은 자식의 종료 코드는 ( 30 )________ 으로 표시한다.

---

## 오늘 정리

| 개념 | 핵심 한 줄 |
| --- | --- |
| 시스템 콜 | 사용자 프로그램이 커널에 일을 부탁하는 유일한 문 |
| errno | 실패(-1) 했을 때만 읽는 원인 번호 |
| /proc | 읽는 순간 커널이 만들어 주는 가상 파일 |
| fork | 한 번 호출, 두 번 반환 (자식 0, 부모 PID) |
| exec | 같은 PID에 새 프로그램을 덮어씀 |
| wait | 자식의 종료 상태 수거 — 안 하면 좀비 |
| 시그널 | 커널이 보내는 비동기 알림, sigaction으로 처리 |

**다음 시간(Day 2, 10/6):** 스케줄링 — 누가, 얼마나 자주, 얼마나 늦게 CPU를 받는가를 측정한다.
